from setuptools import setup


setup(
  name="el_paqueton",
  version="1.0",
  description="Este paquete es mi entrega",
  author="Juan Camilo Infante",
  packages=["ModeloDeClientes"] #pude haber usado también  packages=find_packages()
)